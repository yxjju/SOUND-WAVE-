# SOUND WAVE Android wrapper project

This is a Capacitor Android wrapper starter for the Sound Wave web prototype.

## Build an APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build Sound Wave Android APK** and choose **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the `sound-wave-debug-apk` artifact.
5. Extract the artifact to get `app-debug.apk`.

The APK produced by this workflow is a **debug APK** for testing, not a signed Google Play release.

## Build locally (requires a computer with Android Studio/SDK)
- Install Node.js 20+, Java 21, and Android Studio.
- Run `npm install`
- Run `npx cap add android`
- Run `npx cap sync android`
- Open the `android` folder in Android Studio and build the APK.

## Current functionality and limitations
This wraps the existing web prototype. It does not add production backend services.
- Local audio selection/playback and browser-based microphone monitoring are prototype features.
- Cross-device QR pairing and live audio streaming are not implemented.
- Spotify login/playback integration is not implemented; the button opens Spotify's website.
- A production app needs Android permission review, audio routing/foreground service work, secure backend signaling, WebRTC, consent UI, privacy policy, and testing on real devices.
- For Google Play, create a properly signed release build and meet current Play Console requirements.

## App identity
- App name: SOUND WAVE
- Package ID: com.soundwave.audio
- Version: 0.2.0
